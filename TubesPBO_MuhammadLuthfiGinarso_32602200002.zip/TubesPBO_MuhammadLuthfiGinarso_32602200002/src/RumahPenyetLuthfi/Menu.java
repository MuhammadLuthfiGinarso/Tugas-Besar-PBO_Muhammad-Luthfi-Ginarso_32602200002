package RumahPenyetLuthfi;

/**
 *
 * @author LuthfiGinarso
 */
public class Menu implements Pesan {
    private String nama;
    private double harga;

    public Menu(String nama, double harga) {
        this.nama = nama;
        this.harga = harga;
    }

    @Override
    public void tampilkanInfo() {
        System.out.println(nama + " - Rp " + harga);
    }
    // Getter dan Setter
    public String getNama() {
        return nama;
    }

    public double getHarga() {
        return harga;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }
}
    

