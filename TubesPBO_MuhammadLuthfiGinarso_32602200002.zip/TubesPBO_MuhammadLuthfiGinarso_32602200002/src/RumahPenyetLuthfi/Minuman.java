
package RumahPenyetLuthfi;

/**
 *
 * @author LuthfiGinarso
 */
  public class Minuman extends Menu {
    public Minuman(String nama, double harga) {
        super(nama, harga);
    }
}  
