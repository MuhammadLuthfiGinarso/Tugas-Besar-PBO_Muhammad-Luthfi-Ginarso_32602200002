package RumahPenyetLuthfi;

/**
 *
 * @author LuthfiGinarso
 */
// Interface untuk objek yang dapat dipesan
interface Pesan {
    void tampilkanInfo();
}