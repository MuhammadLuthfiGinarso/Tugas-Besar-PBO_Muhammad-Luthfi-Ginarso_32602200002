
package RumahPenyetLuthfi;

/**
 *
 * @author LuthfiGinarso
 */
import java.util.ArrayList;
import java.util.List;

public class Pemesanan {
    private List<Pesan> pesanan = new ArrayList<>();

    public void tambahPesanan(Pesan item) {
        pesanan.add(item);
    }

    public void tampilkanInfoPesanan() {
        System.out.println("Pesanan Anda:");
        for (Pesan item : pesanan) {
            item.tampilkanInfo();
        }
    }

    public double hitungTotalHarga() {
        double total = 0;
        for (Pesan item : pesanan) {
            total += ((Menu) item).getHarga();
        }
        return total;
    }
}
