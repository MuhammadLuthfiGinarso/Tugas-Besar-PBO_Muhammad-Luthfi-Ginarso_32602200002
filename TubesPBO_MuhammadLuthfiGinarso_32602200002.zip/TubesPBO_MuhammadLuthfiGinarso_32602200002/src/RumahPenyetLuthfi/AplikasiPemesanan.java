package RumahPenyetLuthfi;

/**
 *
 * @author LuthfiGinarso
 */
import java.util.Scanner;

public class AplikasiPemesanan {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Pemesanan pesanan = new Pemesanan();

        // Tambahkan menu makanan dan minuman ke dalam pesanan
        Makanan ayamPenyetDada = new Makanan("Ayam Penyet Dada", 15000);
        Makanan ayamPenyetPaha = new Makanan("Ayam Penyet Paha", 17000);
        Makanan ayamBakarDada = new Makanan("Ayam Bakar Dada", 14000);
        Makanan ayamBakarPaha = new Makanan("Ayam Bakar Paha", 16000);
        Minuman esTeh = new Minuman("Es Teh", 3000);
        Minuman esJeruk = new Minuman("Es Jeruk", 6000);
        Minuman esDawet = new Minuman("Es Dawet",5000);
        
        System.out.println("========================================");
        System.out.println("Selamat Datang Di Rumah Penyet Luthfi");
        System.out.println("========================================\n");
         // Meminta Pengguna memasukkan nama dan nomor meja
        System.out.print("Masukkan Nama Anda  : ");
        String namaPelanggan = scanner.nextLine();
        System.out.print("Masukkan Nomor Meja : ");
        int nomorMeja = scanner.nextInt();
        scanner.nextLine(); // Membersihkan newline character

        // Tampilkan menu yang tersedia
        // ... (kode menu tetap sama)

        // Tampilkan menu yang tersedia
        System.out.println("----Menu yang Tersedia----");
        System.out.println("----------------------------------------------------------");
        System.out.println("Makanan :");
        ayamPenyetDada.tampilkanInfo();
        ayamPenyetPaha.tampilkanInfo();
        ayamBakarDada.tampilkanInfo();
        ayamBakarPaha.tampilkanInfo();
        System.out.println("Minuman :");
        esTeh.tampilkanInfo();
        esJeruk.tampilkanInfo();
        esDawet.tampilkanInfo();

        // Meminta Pengguna memesan makanan atau minuman
        char lanjut;
        do {
            System.out.print("Silahkan Pilih Menu Yang Ingin Anda Pesan : ");
            String pilihan = scanner.nextLine();
            Pesan item = null;
            switch (pilihan.toLowerCase()) {
                case "ayam penyet dada":
                    item = ayamPenyetDada;
                    break;
                case "ayam penyet paha":
                    item = ayamPenyetPaha;
                    break;
                case "ayam bakar dada":
                    item = ayamBakarDada;
                    break;
                case "ayam bakar paha":
                    item = ayamBakarPaha;
                    break;
                case "es teh":
                    item = esTeh;
                    break;
                case "es jeruk":
                    item = esJeruk;
                    break;
                case "es dawet":
                    item = esDawet;
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
                    return;
            }

            pesanan.tambahPesanan(item);

            System.out.print("Ingin menambah pesanan lagi? (ya/tidak): ");
            lanjut = scanner.next().charAt(0);
            scanner.nextLine(); // Membersihkan newline character
        } while (lanjut == 'y' || lanjut == 'Y');

        // Tampilkan informasi pesanan dan total harga
        System.out.println("----------------------------------------------------------\n");
        System.out.println("========================================");
        System.out.println("Informasi Pesanan:");
        System.out.println("========================================");
        System.out.println("Nama Pelanggan: " + namaPelanggan);
        System.out.println("Nomor Meja: " + nomorMeja);
        pesanan.tampilkanInfoPesanan();
        System.out.println("Total Harga: Rp " + pesanan.hitungTotalHarga());
    }
}