
package RumahPenyetLuthfi;

/**
 *
 * @author LuthfiGinarso
 */
public class Makanan extends Menu {
    public Makanan(String nama, double harga) {
        super(nama, harga);
    }
}